
# from demoOops.pyex2 import Day2

class Day1:
    def __init__(balaji):
        balaji.A = 10

    def install(balaji):
        print("we discussed about installation ")

    def basic(balaji):
        print("we discussed about the variables, dtypes and loops")


    def __ide(balaji):
        print("We discussed about IDE and Python Package installation")


class Day2(Day1):
    def controlStmt(balaji):
        print("we discussed about looping like for, while ")

    def funcs(balaji):
        print("we discussed about the functions and modules")



if __name__ == '__main__':
    obj1 = Day1()
    # # obj1.install()
    # obj1.basic()
    # obj1.

    obj2 = Day2()
    # obj2.funcs()

    obj2.basic()
    # obj2.