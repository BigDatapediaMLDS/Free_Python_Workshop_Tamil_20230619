
from demoOops.pyex1 import Day1

class Day2(Day1):
    def controlStmt(self):
        print("we discussed about looping like for, while ")

    def funcs(self):
        print("we discussed about the functions and modules")

